DDWCommon {
	*version { ^"0.1.0" }
}
