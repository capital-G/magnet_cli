// zeta sources
