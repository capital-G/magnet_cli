Zeta { *version { ^"1.2.0" } }
